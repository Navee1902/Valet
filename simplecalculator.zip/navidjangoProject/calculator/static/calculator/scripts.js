let display = document.getElementById('display');
let currentInput = '';
let currentOperation = null;
let firstOperand = null;

function appendNumber(number) {
    currentInput += number;
    display.textContent = currentInput;
}

function chooseOperation(operation) {
    if (currentInput === '') return;
    if (firstOperand !== null) {
        compute();
    }
    currentOperation = operation;
    firstOperand = parseFloat(currentInput);
    currentInput = '';
}

function clearDisplay() {
    currentInput = '';
    currentOperation = null;
    firstOperand = null;
    display.textContent = '';
}

function compute() {
    if (currentInput === '' || currentOperation === null) return;
    let secondOperand = parseFloat(currentInput);
    let result;
    switch (currentOperation) {
        case '+':
            result = firstOperand + secondOperand;
            break;
        case '-':
            result = firstOperand - secondOperand;
            break;
        case '*':
            result = firstOperand * secondOperand;
            break;
        case '/':
            result = firstOperand / secondOperand;
            break;
        default:
            return;
    }
    display.textContent = result;
    currentInput = result.toString();
    currentOperation = null;
    firstOperand = null;
}
